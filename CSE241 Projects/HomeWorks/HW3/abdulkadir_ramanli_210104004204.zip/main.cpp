#include <iostream>
#include "SchoolManagementSystem.h"

using namespace std;

int main()
{
    SchoolManagementSystem sms;
    sms.menu();

    return 0;
}